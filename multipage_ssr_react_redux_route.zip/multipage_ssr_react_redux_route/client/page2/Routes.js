import React from 'react'
import Dashboard from './components/Dashboard'

export default [
  {
    ...Dashboard,
    path: '/page2',
    exact: true
  }
];
