const path = require('path');
const merge = require('webpack-merge');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const ManifestPlugin = require('webpack-manifest-plugin');

const baseConfig = require('./webpack.base.config.js');

const config = {
  // Tell webpack the root file of our
  // server application
  //entry: './client/page1/client.js',
  entry: {
  	page1: './client/page1/client.js',
  	page2: './client/page2/client.js'
  },

  // Tell webpack where to put the output file
  // that is generated
  output: {
    filename: '[name]/[name].[chunkhash].js',
    path: path.resolve(__dirname, 'public')
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: "[name]/[name].[chunkhash].css"
    }),
    new ManifestPlugin(),
  ]
};

module.exports = merge(baseConfig, config);
	