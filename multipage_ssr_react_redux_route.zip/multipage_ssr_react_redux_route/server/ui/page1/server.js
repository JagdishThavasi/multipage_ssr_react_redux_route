import React from 'react'
import { renderToString } from 'react-dom/server'
import { StaticRouter } from 'react-router-dom'
import { Provider } from 'react-redux'
import { renderRoutes } from 'react-router-config'
import serialize from 'serialize-javascript'
import Routes from '../../../client/page1/Routes'
let manifestJSON = require('../../../public/manifest.json');
manifestJSON['page1.js'] = '/' + manifestJSON['page1.js'];
manifestJSON['page1.css'] = '/' + manifestJSON['page1.css'];
export default (req, store) => {
  const content = renderToString(
    <Provider store={store}>
      <StaticRouter location={req.path} context={{}}>
        <div>{renderRoutes(Routes)}</div>
      </StaticRouter>
    </Provider>
  );

  return `
    <html>
      <head>
      <link rel="stylesheet" type="text/css" href=${manifestJSON['page1.css']}>
      </head>
      <body>
        <div id="root">${content}</div>
        <script>
          window.INITIAL_STATE = ${serialize(store.getState())}
        </script>
        <script src=${manifestJSON['page1.js']}></script>
      </body>
    </html>
  `;
};
