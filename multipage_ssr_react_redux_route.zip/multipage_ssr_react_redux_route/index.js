import 'babel-polyfill'
import express from 'express'
import { matchRoutes } from 'react-router-config'
import routes1 from './client/page1/Routes'
import routes2 from './client/page2/Routes'
import server1 from './server/ui/page1/server'
import server2 from './server/ui/page2/server'
import createStore1 from './server/ui/page1/createStore'
import createStore2 from './server/ui/page2/createStore'
import api from './server/api/index.js'
const model = require('./server/api/model.json')
const bodyParser = require('body-parser')

const app = express();
app.use(bodyParser.json());
app.use(express.static('public'))
app.get('/page1', (req, res) => {
  let store = createStore1()
  let promises = matchRoutes(routes1, req.path).map(({ route }) => {
    return route.loadData ? route.loadData(store) : null
  });

  Promise.all(promises).then(() => {
    res.send(server1(req, store))
  });
});

app.get('/page2', (req, res) => {
  let store = createStore2()
  let promises = matchRoutes(routes2, req.path).map(({ route }) => {
    return route.loadData ? route.loadData(store) : null
  });

  Promise.all(promises).then(() => {
    res.send(server2(req, store))
  });
});

app.post('/load', (req, res) => api(req, res));

app.listen(3030, () => {
  console.log('Listening on prot 3000')
});
