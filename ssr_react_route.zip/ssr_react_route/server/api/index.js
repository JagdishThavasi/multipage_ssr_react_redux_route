const model = require('./model.json')
export default (req, res) => res.send(model.acntData.slice(0,req.body.loadCount));


